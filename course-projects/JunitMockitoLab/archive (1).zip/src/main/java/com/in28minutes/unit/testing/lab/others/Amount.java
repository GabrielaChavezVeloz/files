package com.in28minutes.unit.testing.lab.others;
import java.math.BigDecimal;

public interface Amount {
	BigDecimal getValue();

	Currency getCurrency();
}
