package com.in28minutes.unit.testing.lab.others;

import java.util.List;

public interface CustomerDataService {

	List<Product> retrieveCustomerProducts(String id);

}
