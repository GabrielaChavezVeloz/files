package com.in28minutes.unit.testing.lab.others;
public class SomeDataService {
	public int[] retrieveData() {
		throw new RuntimeException("Unimplemented");
	}
}
