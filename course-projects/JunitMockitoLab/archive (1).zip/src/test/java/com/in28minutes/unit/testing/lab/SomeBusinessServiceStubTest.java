package com.in28minutes.unit.testing.lab;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import com.in28minutes.unit.testing.lab.others.SomeDataService;

public class SomeBusinessServiceStubTest {
		
	@Test
	public void testCalculateSum() {	
		
		//Create stub SomeDataService implementation with hardcoded implementation for retrieveData
		
		//Create SomeBusinessService using the stub SomeDataService implementation
		
		//Write your test scenario
	}
	
}
