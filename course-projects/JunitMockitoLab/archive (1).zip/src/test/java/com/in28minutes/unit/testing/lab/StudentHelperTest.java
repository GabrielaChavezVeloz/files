package com.in28minutes.unit.testing.lab;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;


public class StudentHelperTest {

	private static final int UPPER_LIMIT_FOR_NOT_MATHS = 80;
	private static final int UPPER_LIMIT_FOR_MATHS = UPPER_LIMIT_FOR_NOT_MATHS + 10;
	private static final int LOWER_LIMIT_FOR_NOT_MATHS = 51;
	private static final int LOWER_LIMIT_FOR_MATHS = LOWER_LIMIT_FOR_NOT_MATHS + 10;

	private static final boolean MATHS = true;

	private static final boolean NOT_MATHS = false;
	
	StudentHelper helper = new StudentHelper();
	
	@Test
	public void testIsGradeB() {
		
	}

}
