package com.ecommerce.udemy.coursesservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoursesServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
