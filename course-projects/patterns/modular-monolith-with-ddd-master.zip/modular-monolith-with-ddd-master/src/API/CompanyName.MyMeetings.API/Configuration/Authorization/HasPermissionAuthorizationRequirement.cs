﻿using Microsoft.AspNetCore.Authorization;

namespace CompanyName.MyMeetings.API.Configuration.Authorization
{
    public class HasPermissionAuthorizationRequirement : IAuthorizationRequirement
    {
    }
}