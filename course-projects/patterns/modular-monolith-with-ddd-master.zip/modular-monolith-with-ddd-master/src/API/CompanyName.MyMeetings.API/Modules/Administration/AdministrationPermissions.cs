﻿namespace CompanyName.MyMeetings.API.Modules.Administration
{
    public class AdministrationPermissions
    {
        public const string AcceptMeetingGroupProposal = "AcceptMeetingGroupProposal";
    }
}