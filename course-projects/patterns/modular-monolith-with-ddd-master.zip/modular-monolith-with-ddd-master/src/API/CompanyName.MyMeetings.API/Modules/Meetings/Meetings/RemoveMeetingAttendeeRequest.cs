﻿namespace CompanyName.MyMeetings.API.Modules.Meetings.Meetings
{
    public class RemoveMeetingAttendeeRequest
    {
        public string RemovingReason { get; set; }
    }
}