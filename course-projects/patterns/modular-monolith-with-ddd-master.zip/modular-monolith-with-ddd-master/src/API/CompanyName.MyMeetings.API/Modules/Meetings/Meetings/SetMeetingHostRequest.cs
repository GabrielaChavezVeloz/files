﻿using System;

namespace CompanyName.MyMeetings.API.Modules.Meetings.Meetings
{
    public class SetMeetingHostRequest
    {
        public Guid AttendeeId { get; set; }
    }
}