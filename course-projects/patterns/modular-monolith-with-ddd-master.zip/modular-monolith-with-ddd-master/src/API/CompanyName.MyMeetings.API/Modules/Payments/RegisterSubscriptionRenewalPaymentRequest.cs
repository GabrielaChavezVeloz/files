using System;

namespace CompanyName.MyMeetings.API.Modules.Payments
{
    public class RegisterSubscriptionRenewalPaymentRequest
    {
        public Guid PaymentId { get; set; }
    }
}