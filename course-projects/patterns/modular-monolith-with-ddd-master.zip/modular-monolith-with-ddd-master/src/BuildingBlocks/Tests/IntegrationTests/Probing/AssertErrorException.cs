﻿using System;

namespace CompanyName.MyMeetings.BuildingBlocks.IntegrationTests.Probing
{
    public class AssertErrorException : Exception
    {
        public AssertErrorException(string message)
            : base(message)
        {
        }
    }
}