﻿ALTER TABLE [meetings].[MeetingComments] ADD [LikesCount] INT DEFAULT 0
GO