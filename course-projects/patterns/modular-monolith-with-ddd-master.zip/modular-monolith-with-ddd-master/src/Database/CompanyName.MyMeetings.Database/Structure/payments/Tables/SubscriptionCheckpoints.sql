﻿CREATE TABLE payments.SubscriptionCheckpoints
(
    [Code] VARCHAR(50) NOT NULL,
    [Position] BIGINT NOT NULL
)