﻿CREATE TABLE [users].[UserRoles]
(
    [UserId] UNIQUEIDENTIFIER NOT NULL,
    [RoleCode] NVARCHAR(50)
)
GO