﻿using System;

namespace CompanyName.MyMeetings.Modules.Administration.Domain.Users
{
    public interface IUserContext
    {
        UserId UserId { get; }
    }
}