﻿namespace CompanyName.MyMeetings.Modules.Administration.Infrastructure.Configuration.Processing
{
    public interface IRecurringCommand
    {
    }
}