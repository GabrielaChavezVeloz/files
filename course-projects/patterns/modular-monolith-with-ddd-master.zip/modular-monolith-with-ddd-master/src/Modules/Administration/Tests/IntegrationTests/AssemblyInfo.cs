﻿using NUnit.Framework;

[assembly: NonParallelizable]
[assembly: LevelOfParallelism(1)]

namespace CompanyName.MyMeetings.Modules.Administration.IntegrationTests
{
    public class AssemblyInfo
    {
    }
}