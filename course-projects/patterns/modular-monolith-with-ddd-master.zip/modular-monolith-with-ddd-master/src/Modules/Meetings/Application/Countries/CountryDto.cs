﻿namespace CompanyName.MyMeetings.Modules.Meetings.Application.Countries
{
    public class CountryDto
    {
        public string Code { get; set; }

        public string Name { get; set; }
    }
}