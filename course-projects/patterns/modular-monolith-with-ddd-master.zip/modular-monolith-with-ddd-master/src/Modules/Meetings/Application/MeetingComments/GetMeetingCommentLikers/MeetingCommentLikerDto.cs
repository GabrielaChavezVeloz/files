﻿using System;

namespace CompanyName.MyMeetings.Modules.Meetings.Application.MeetingComments.GetMeetingCommentLikes
{
    public class MeetingCommentLikerDto
    {
        public Guid Id { get; set; }

        public string Name { get; set; }
    }
}