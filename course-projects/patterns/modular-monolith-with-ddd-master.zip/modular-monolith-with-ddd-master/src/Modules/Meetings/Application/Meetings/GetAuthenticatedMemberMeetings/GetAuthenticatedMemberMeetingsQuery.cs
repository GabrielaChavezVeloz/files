﻿using System.Collections.Generic;
using CompanyName.MyMeetings.Modules.Meetings.Application.Configuration.Queries;

namespace CompanyName.MyMeetings.Modules.Meetings.Application.Meetings.GetAuthenticatedMemberMeetings
{
    public class GetAuthenticatedMemberMeetingsQuery : QueryBase<List<MemberMeetingDto>>
    {
    }
}